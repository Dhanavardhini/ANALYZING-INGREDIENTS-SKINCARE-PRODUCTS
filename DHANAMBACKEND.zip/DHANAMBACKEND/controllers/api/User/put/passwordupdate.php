<?php
$modelsPath = '../../../../models/put.php';
$headersPath = '../../../../config/header.php';

// Debugging: Check if the files exist
if (!file_exists($modelsPath)) {
    handleResponse(500, "Required file missing: models/put.php");
    return;
}
if (!file_exists($headersPath)) {
    handleResponse(500, "Required file missing: config/header.php");
    return;
}

require_once $modelsPath;
require_once $headersPath;

function handleResponse($statusCode, $message) {
    http_response_code($statusCode);
    echo json_encode(['error' => $message]);
    exit();
}

$data = json_decode(file_get_contents('php://input'));
$requiredFields = ['email', 'password'];

foreach ($requiredFields as $field) {
    if (!isset($data->$field)) {
        handleResponse(400, "Missing required field: $field");
    }
}

$obj = new Put();
$result = $obj->updatePassword($data->email, $data->password);
echo json_encode($result);
?>
