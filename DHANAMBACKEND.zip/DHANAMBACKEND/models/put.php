<?php
include_once '../../../../config/database.php';

class Put
{
    public $conn;
    public $response;

    function __construct()
    {
        $db = new Database();
        $this->conn = $db->connect();
    }

    public function updatePassword($email, $Password) 
    {
        $query = "UPDATE register SET password = ? WHERE email = ?";
        $stmt = mysqli_prepare($this->conn, $query);

        if (!$stmt) {
            return ["error" => "Query preparation error: " . mysqli_error($this->conn)];
        }

        mysqli_stmt_bind_param($stmt, 'ss', $Password, $email);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            return ["success" => "Password updated successfully"];
        } else {
            return ["error" => "Failed to update password"];
        }
    }
}
    

?>